<template>
  <div class="container">
    <h1 class="title">Search Page</h1>
    <SearchRecipePreviewList title="search res Recipes"/>
  </div>
</template>
<script>
import SearchRecipePreviewList from '../components/SearchRecipePreviewList';
export default {
  components:{
    SearchRecipePreviewList
  }
};
</script>
